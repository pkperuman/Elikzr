﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NextUsWeb.Controllers
{
    public class ResidentController : Controller
    {
        //
        // GET: /Resident/

        public ActionResult Index()
        {
            return View();
        }

    }
}
